﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace SocialMediaSharing
{
    public partial class Form1 : Form
    {
        string filePath;
        string fileExtention;
        bool error = false;
        bool loggin = false;
        string gebruikersnaam;
        string wachtwoord;

        private OracleConnection conn;

        int dezevariablevoordedatabase;
        GroupBox gbUser;
        GroupBox gbMappen;
        Button btn;
        Button btn2;
        TextBox tbBericht;
        List<Button> buttonss = new List<Button>();
        List<Control> dynControls = new List<Control>();

        Mediasharing mediasharing = new Mediasharing();
        Bericht bericht = new Bericht();
        List<Bezoeker> bezoekers = new List<Bezoeker>();
        List<Map> mappen = new List<Map>();
        List<Friend> friends = new List<Friend>();

        public Form1()
        {
            InitializeComponent();
            conn = new OracleConnection();
            ConnectDatabase();
        }
        public void ConnectDatabase()
        {
            try
            {
                String user = "dbi323305"; //gebruikersnaam van je database
                String pw = "nGgnLfwiJE"; //wachtwoord van je database
                conn.ConnectionString = "User Id=" + user + ";Password=" + pw + ";Data Source=" + " //192.168.15.50:1521/fhictora" + ";";  //string om verbinding te maken, kan ook handmatig
                conn.Open(); //opent connectie met de Connectionstring die voor deze connectie is ingesteld
                MessageBox.Show("Connectie gelukt!");
            }
            catch { error = true; }
            if (error)
            {
                error = false;
                //throw new DatabaseConnectionFailed(" Er ging iets mis met de connectie");
            }

            try
            {
                OracleCommand cmd = conn.CreateCommand(); //oraclecommand opstellen, eerste waarde in de haakjes is je SQL string en de 2de is je connectie
                cmd.CommandType = CommandType.Text; //commandtype instellen, dit is meestal text
                cmd.CommandText = "SELECT toegankelijkheid, accountnaam, accountwachtwoord FROM bezoeker";

                OracleDataReader dr = cmd.ExecuteReader(); //een OracleDataReader aanmaken en deze linken aan het command dat je zojuist hebt gemaakt.
                while (dr.Read()) //leest het OracleDatareader en daarmee het command dat je eraan linkt.
                {
                    Bezoeker b = new Bezoeker(dr.GetString(0), dr.GetString(1), dr.GetString(2));
                    bezoekers.Add(b);
                }
                dr.Close();
                cmd.Dispose(); //verwijdert command
                conn.Close();
            }
            catch { MessageBox.Show("Geen gegevens in de database gevonden."); }
        }

        private void btnInloggen_Click(object sender, EventArgs e)
        {
            gebruikersnaam = tbUsername.Text;
            wachtwoord = tbPassword.Text;
            foreach (Bezoeker b in bezoekers)
            {
                if (b.AccountNaam == gebruikersnaam && b.AccountWachtwoord == wachtwoord)
                {
                    this.loggin = true;
                    //TODO: match toegangscode met behorende applicatie.
                    if (b.Toegankelijkheid == "A" || b.Toegankelijkheid == "E" || b.Toegankelijkheid == "F")
                    {
                        //TODO: open je form.
                        //Mappen laden
                        try
                        {
                            OracleCommand cmd = conn.CreateCommand(); //oraclecommand opstellen, eerste waarde in de haakjes is je SQL string en de 2de is je connectie
                            cmd.CommandType = CommandType.Text; //commandtype instellen, dit is meestal text
                            cmd.CommandText = "SELECT mapID, mapnaam FROM mediamap WHERE submapID IS NULL";

                            OracleDataReader dr = cmd.ExecuteReader(); //een OracleDataReader aanmaken en deze linken aan het command dat je zojuist hebt gemaakt.
                            while (dr.Read()) //leest het OracleDatareader en daarmee het command dat je eraan linkt.
                            {
                                Map m = new Map(dr.GetString(0), dr.GetString(1));
                                mappen.Add(m);
                            }
                            dr.Close();
                            cmd.Dispose(); //verwijdert command
                            conn.Close();
                        }
                        catch { MessageBox.Show("geen gegevens gevonden in de database 2.0"); }

                        //dezevariablevoordedatabase = 3; // De drie moet dus voor gekekene worden in de database.

                        maakHome();
                        mappenAanmaken();


                        //Dit is om te kijken of het werkt.
                        //ListBox lbWelkeButtonsZijnEr = new ListBox();
                        //lbWelkeButtonsZijnEr.Location = new Point(750, 50);
                        //lbWelkeButtonsZijnEr.Size = new Size(350, 300);
                        //this.Controls.Add(lbWelkeButtonsZijnEr);
                        //dynControls.Add(lbWelkeButtonsZijnEr);
                        ////TEST
                        //lbWelkeButtonsZijnEr.Items.Add("Dit was om te testen of de knoppen andere namen kregen.");
                        foreach (Button but in buttonss)
                        {
                            //    lbWelkeButtonsZijnEr.Items.Add(b.Name);
                        }
                    }
                    else
                    {
                        MessageBox.Show("U hebt helaas geen toegang tot deze applicatie.");
                    }
                }
            }
            if (loggin == false)
            {
                MessageBox.Show("Ongeldige gebruikersnaam/wachtwoord.");
            }
            loggin = false;

            
        }

        public void btn_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            MessageBox.Show(button.Name);
            if(button.Name == "btn01")
            {
                MessageBox.Show("Deze komt alleen als je op deze button clickt.");
            }
        }

        public void btnFriends_Click(object sender, EventArgs e)
        {
            maakLeeg();
            //Geef een lijst met alle vrienden
            
            //Friends ophalen uit de  database.
            ListBox lbFriends = new ListBox();
            lbFriends.Location = new Point(20, 10);
            lbFriends.Size = new Size(750, 700);
            this.Controls.Add(lbFriends);
            dynControls.Add(lbFriends);

            foreach (Friend f in friends)
            {
                lbFriends.Items.Add(f);
            }
        }

        public void btnUploaden_Click(object sender, EventArgs e)
        {
            //mediasharing.Upload(); // 2 arguments uit de DB.
            if (Uploaden.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("Dit is het pad naar de file:   " + Path.GetFullPath(Uploaden.FileName) + "\n" + "De extensie is:   " + Path.GetExtension(Uploaden.FileName));
                filePath = Path.GetFullPath(Uploaden.FileName);
                fileExtention = Path.GetExtension(Uploaden.FileName);
            }
 
        }

        public void btnBerichtplaatsen_Click(object sender, EventArgs e)
        {
            if(tbBericht.Text != "")
            {
                //Insert into database.
                bericht.BerichtPlaatsen("mediaID uit database", tbBericht.Text);
                MessageBox.Show("Uw bericht: " + tbBericht.Text + "\n" + "is geplaatst.");
            }
            else
            {
                MessageBox.Show("U dient eerst een bericht te typen.");
            }

        }

        public void btnMapAanmaken_Click(object sender, EventArgs e)
        {
            dezevariablevoordedatabase++;
            if (dezevariablevoordedatabase % 2 == 0)
            {
                gbMappen.Size = new Size(500, 120 + dezevariablevoordedatabase * 50 );
            }
            mappenAanmaken();
        }

        public void btn2_Click(object sender, EventArgs e)
        {
            Button button2 = sender as Button;
            MessageBox.Show(button2.Name);


        }

        public void maakLogUitButton()
        {
            Button btnLogUit = new Button();
            btnLogUit.Location = new Point(1110, 10);
            btnLogUit.Size = new Size(60, 50);
            btnLogUit.Text = "Log uit";
            this.Controls.Add(btnLogUit);
            btnLogUit.Click += new EventHandler(this.btnLogUit_Click);
            dynControls.Add(btnLogUit);
        }

        public void maakLeeg()
        {
            foreach (Control c in dynControls)
            {
                this.Controls.Remove(c);
            }
        }

        public void mappenAanmaken()
        {
            if (dezevariablevoordedatabase % 2 == 0) // Dan is het een even aantal mappen.
            {
                for (int i = 0; i < dezevariablevoordedatabase / 2; i++)
                {
                    btn = new Button();
                    btn.Name = "btn0" + i.ToString();
                    btn.Text = "btn0" + i.ToString();
                    btn.Location = new Point(50, 50 + 100 * i);
                    btn.Size = new Size(180, 50);
                    gbMappen.Controls.Add(btn);
                    btn.Click += new EventHandler(this.btn_Click);
                    buttonss.Add(btn);
                    dynControls.Add(btn);

                    btn2 = new Button();
                    btn2.Name = "btn1" + i.ToString();
                    btn2.Text = "btn1" + i.ToString();
                    btn2.Location = new Point(300, 50 + 100 * i);
                    btn2.Size = new Size(180, 50);
                    gbMappen.Controls.Add(btn2);
                    btn2.Click += new EventHandler(this.btn2_Click);
                    buttonss.Add(btn2);
                    dynControls.Add(btn2);
                }
            }
            else // Dan is het dus een oneven aantal.
            {
                for (int i = 0; i < (dezevariablevoordedatabase - 1) / 2; i++)
                {
                    btn = new Button();
                    btn.Name = "btn0" + i.ToString();
                    btn.Text = "btn0" + i.ToString();
                    btn.Location = new Point(50, 50 + 100 * i);
                    btn.Size = new Size(180, 50);
                    gbMappen.Controls.Add(btn);
                    btn.Click += new EventHandler(this.btn_Click);
                    buttonss.Add(btn);
                    dynControls.Add(btn);

                    btn2 = new Button();
                    btn2.Name = "btn1" + i.ToString();
                    btn2.Text = "btn1" + i.ToString();
                    btn2.Location = new Point(300, 50 + 100 * i);
                    btn2.Size = new Size(180, 50);
                    gbMappen.Controls.Add(btn2);
                    btn2.Click += new EventHandler(this.btn2_Click);
                    buttonss.Add(btn2);
                    dynControls.Add(btn2);
                }
                btn = new Button();
                btn.Name = "btn0" + (dezevariablevoordedatabase - 1) / 2;
                btn.Text = "btn0" + (dezevariablevoordedatabase - 1) / 2;
                btn.Location = new Point(50, 50 + 100 * (dezevariablevoordedatabase - 1) / 2);
                btn.Size = new Size(180, 50);
                gbMappen.Controls.Add(btn);
                btn.Click += new EventHandler(this.btn_Click);
                buttonss.Add(btn);
                dynControls.Add(btn);
            }
        }

        public void maakHome()
        {

            dezevariablevoordedatabase = 4;
            Panel panelUser = new Panel();
            panelUser.Location = new Point(3, 3);
            panelUser.Size = new Size(210, 630);
            this.Controls.Add(panelUser);
            dynControls.Add(panelUser);

            Panel panelOther = new Panel();
            panelOther.Location = new Point(20, 10);
            panelOther.Size = new Size(750, 700);
            panelOther.AutoScroll = true;
            this.Controls.Add(panelOther);
            dynControls.Add(panelOther);

            gbLogin.Visible = false;
            gbUser = new GroupBox();
            gbUser.Location = new Point(10, 10);
            gbUser.Size = new Size(200, 600);
            gbUser.Text = "User";
            gbUser.Anchor = AnchorStyles.Left | AnchorStyles.Top;

            panelUser.Controls.Add(gbUser);
            dynControls.Add(gbUser);

            gbMappen = new GroupBox();
            gbMappen.Location = new Point(220, 5);
            gbMappen.Size = new Size(500, 100 * dezevariablevoordedatabase);
            gbMappen.Text = "Mappen";
            panelOther.Controls.Add(gbMappen);

            Label lblName = new Label();
            lblName.Location = new Point(20, 25);
            lblName.Size = new Size(150, 40);
            lblName.Text = "De naam"; // dit moet uit de database komen.
            gbUser.Controls.Add(lblName);

            Button btnFriends = new Button();
            btnFriends.Location = new Point(15, 300);
            btnFriends.Size = new Size(80, 40);
            btnFriends.Text = "Friends";
            btnFriends.Click += new EventHandler(this.btnFriends_Click);
            gbUser.Controls.Add(btnFriends);
            maakLogUitButton();

            Button btnUploaden = new Button();
            btnUploaden.Location = new Point(900, 100);
            btnUploaden.Size = new Size(80, 40);
            btnUploaden.Text = "Uploaden";
            btnUploaden.Click += new EventHandler(this.btnUploaden_Click);
            btnFriends.Anchor = AnchorStyles.Left;
            this.Controls.Add(btnUploaden);
            dynControls.Add(btnUploaden);

            tbBericht = new TextBox();
            tbBericht.Location = new Point(820, 500);
            tbBericht.Size = new Size(250, 100);
            this.Controls.Add(tbBericht);
            dynControls.Add(tbBericht);

            Button btnBerichtPlaatsen = new Button();
            btnBerichtPlaatsen.Location = new Point(820, 550);
            btnBerichtPlaatsen.Size = new Size(100, 50);
            btnBerichtPlaatsen.Text = "Plaats bericht";
            btnBerichtPlaatsen.Click += new EventHandler(this.btnBerichtplaatsen_Click);
            this.Controls.Add(btnBerichtPlaatsen);
            dynControls.Add(btnBerichtPlaatsen);

            Button btnMapAanmaken = new Button();
            btnMapAanmaken.Location = new Point(15, 540);
            btnMapAanmaken.Size = new Size(100, 50);
            btnMapAanmaken.Text = "Maak nieuwe map aan";
            btnMapAanmaken.Click += new EventHandler(this.btnMapAanmaken_Click);
            gbUser.Controls.Add(btnMapAanmaken);
            dynControls.Add(btnMapAanmaken);
        }

        public void btnLogUit_Click(object sender, System.EventArgs e)
        {
            maakLeeg();
            gbLogin.Visible = true;
        }
    }
}
