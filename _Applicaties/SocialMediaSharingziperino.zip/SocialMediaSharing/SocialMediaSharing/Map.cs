﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialMediaSharing
{
    class Map
    {
        public string MapID { get; set; }

        public string SubmapID { get; set; }

        public string MapNaam { get; set; }

        public string BezoekerID { get; set; }

        public Map(string mapID, string mapNaam)
        {
            this.MapID = mapID;
            this.MapNaam = mapNaam;
        }
        public Map(string bezoekerID, string mapID, string submapID, string mapNaam)
        {
            this.BezoekerID = bezoekerID;
            this.MapID = mapID;
            this.SubmapID = submapID;
            this.MapNaam = mapNaam;
        }
    }
}
