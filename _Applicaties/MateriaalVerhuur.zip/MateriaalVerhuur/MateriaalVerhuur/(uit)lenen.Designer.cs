﻿namespace MateriaalVerhuur
{
    partial class _uit_lenen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerhuur = new System.Windows.Forms.Button();
            this.btnTerugbrengen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnVerhuur
            // 
            this.btnVerhuur.Location = new System.Drawing.Point(351, 135);
            this.btnVerhuur.Name = "btnVerhuur";
            this.btnVerhuur.Size = new System.Drawing.Size(450, 150);
            this.btnVerhuur.TabIndex = 0;
            this.btnVerhuur.Text = "Verhuren";
            this.btnVerhuur.UseVisualStyleBackColor = true;
            // 
            // btnTerugbrengen
            // 
            this.btnTerugbrengen.Location = new System.Drawing.Point(351, 404);
            this.btnTerugbrengen.Name = "btnTerugbrengen";
            this.btnTerugbrengen.Size = new System.Drawing.Size(450, 150);
            this.btnTerugbrengen.TabIndex = 1;
            this.btnTerugbrengen.Text = "Terugbrengen";
            this.btnTerugbrengen.UseVisualStyleBackColor = true;
            // 
            // _uit_lenen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 705);
            this.Controls.Add(this.btnTerugbrengen);
            this.Controls.Add(this.btnVerhuur);
            this.Name = "_uit_lenen";
            this.Text = "Materiaal Verhuur";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVerhuur;
        private System.Windows.Forms.Button btnTerugbrengen;
    }
}