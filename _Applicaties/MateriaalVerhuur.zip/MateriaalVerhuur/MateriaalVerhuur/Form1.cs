﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MateriaalVerhuur
{
    public partial class Form1 : Form
    {
        Form2 uitlenen = new Form2();
        List<Control> dynControls = new List<Control>();

        string username;
        string password;
        bool RFIDscanned = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInloggen_Click(object sender, EventArgs e)
        {
            username = tbUsername.Text;
            password = tbPassword.Text;

            if(username == "" && password == "")
            {
                MessageBox.Show("U bent succesvol ingelogd ^.^ ");
                gbLogin.Visible = false;

                terugHome();
                //uitlenen.ShowDialog();
                //this.Close();
            }
            else
            {
                MessageBox.Show("Gebruikersnaam en/of wachtwoord heeft geen match.");
            }
        }

        public void maakLogUitButton()
        {
                Button btnLogUit = new Button();
                btnLogUit.Location = new Point(1110, 10);
                btnLogUit.Size = new Size(60, 50);
                btnLogUit.Text = "Log uit";
                this.Controls.Add(btnLogUit);
                btnLogUit.Click += new EventHandler(this.btnLogUit_Click);
                dynControls.Add(btnLogUit);
        }

        public void maakHomeButton()
        {
            Button btnHome = new Button();
            btnHome.Location = new Point(10, 10);
            btnHome.Size = new Size(60, 50);
            btnHome.Text = "Home";
            this.Controls.Add(btnHome);
            btnHome.Click += new EventHandler(this.btnHome_Click);
            dynControls.Add(btnHome);
        }

        public void terugHome()
        {
            Button btnVerhuren = new Button();
            btnVerhuren.Location = new Point(375, 100);
            btnVerhuren.Size = new Size(450, 150);
            btnVerhuren.Text = "Verhuren";
            this.Controls.Add(btnVerhuren);
            btnVerhuren.Click += new EventHandler(this.btnVerhuur_Click);
            dynControls.Add(btnVerhuren);

            Button btnTerugbrengen = new Button();
            btnTerugbrengen.Location = new Point(375, 350);
            btnTerugbrengen.Size = new Size(450, 150);
            btnTerugbrengen.Text = "Terugbrengen";
            this.Controls.Add(btnTerugbrengen);
            btnTerugbrengen.Click += new EventHandler(this.btnTerugBrengen_Click);
            dynControls.Add(btnTerugbrengen);

            maakLogUitButton();
            maakHomeButton();
        }

        public void maakLeeg()
        {
            foreach (Control c in dynControls)
            {
                this.Controls.Remove(c);
            }
        }

        public void btnVerhuur_Click(object sender, System.EventArgs e)
        {
            MessageBox.Show("Scan de RFID van de bezoeker." + "\n" + "\n" + "Druk daarna op OK");

            maakLeeg();

            Label lbWachtOpScan = new Label();
            lbWachtOpScan.Location = new Point(400, 300);
            lbWachtOpScan.Size = new Size(1000, 50);
            lbWachtOpScan.Font = new Font("Microsoft Sans Serif", 20F);
            lbWachtOpScan.Text = "Scan het voorwerp... ...";
            this.Controls.Add(lbWachtOpScan);
            dynControls.Add(lbWachtOpScan);

            RFIDscanned = true;
            while(RFIDscanned != false)
            if (RFIDscanned)
            {
                RFIDscanned = false;
                foreach (Control b in dynControls)
                {
                    this.Controls.Remove(b);

                }

                ListBox lbVerhuurbareItems = new ListBox();
                lbVerhuurbareItems.Location = new Point(350, 50);
                lbVerhuurbareItems.Size = new Size(400, 600);
                this.Controls.Add(lbVerhuurbareItems);
                dynControls.Add(lbVerhuurbareItems);

                //lbVerhuurbareItems.Items.Add();

                Label listboxlabel = new Label();
                listboxlabel.Location = new Point(350, 30);
                listboxlabel.Size = new Size(300, 20);
                listboxlabel.Text = "Selecteer een voorwerp uit onderstaande lijst.";
                this.Controls.Add(listboxlabel);
                dynControls.Add(listboxlabel);

                //lbVerhuurbareItems.Items.Add();

                Button btnVerhuren = new Button();
                btnVerhuren.Location = new Point(800, 100);
                btnVerhuren.Size = new Size(150, 50);
                btnVerhuren.Text = "Verhuren";
                this.Controls.Add(btnVerhuren);
                dynControls.Add(btnVerhuren);

                btnVerhuren.Click += new EventHandler(this.btnVerhuren_Click);
            }
            maakLogUitButton();
            maakHomeButton();
        }

        public void btnTerugBrengen_Click(object sender, System.EventArgs e)
        {
            maakLeeg();

          //  MessageBox.Show("Scan de RFID van de bezoeker." + "\n" + "Druk daarna op OK");
            Label lbWachtOpScan = new Label();
            lbWachtOpScan.Location = new Point(400, 300);
            lbWachtOpScan.Size = new Size(1000, 50);
            lbWachtOpScan.Font = new Font("Microsoft Sans Serif", 20F);
            lbWachtOpScan.Text = "Scan het voorwerp... ...";
            this.Controls.Add(lbWachtOpScan);
            dynControls.Add(lbWachtOpScan);

            RFIDscanned = true;
            while (RFIDscanned != false)
            {
                
                if (RFIDscanned)
                {
                    RFIDscanned = false;
                    maakLeeg();
                    //alle rest van le code;

                    Label bezNaam = new Label();
                    bezNaam.Location = new Point(75, 150);
                    bezNaam.Size = new Size(60, 50);
                    bezNaam.Text = "Naam:";
                    this.Controls.Add(bezNaam);
                    dynControls.Add(bezNaam);
                    //Label aanpassen met data databaseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
                    //Label bezRFID = new Label();
                    //bezRFID.Location = new Point(100, 200);
                    //bezRFID.Size = new Size(100, 50);
                    //bezRFID.Text = "RFID  code:";
                    //this.Controls.Add(bezRFID);
                    //dynControls.Add(bezRFID);

                    ListBox lbGehuurdeItems = new ListBox();
                    lbGehuurdeItems.Location = new Point(400, 50);
                    lbGehuurdeItems.Size = new Size(400, 600);
                    this.Controls.Add(lbGehuurdeItems);
                    dynControls.Add(lbGehuurdeItems);

                    //lbGehuurdeItems.Items.Add();

                    Button btnTerugBrengen = new Button();
                    btnTerugBrengen.Location = new Point(850, 100);
                    btnTerugBrengen.Size = new Size(150, 50);
                    btnTerugBrengen.Text = "Terug brengen";
                    this.Controls.Add(btnTerugBrengen);
                    dynControls.Add(btnTerugBrengen);

                    btnTerugBrengen.Click += new EventHandler(this.btnTerugbrengen_Click);
                }
            }
            maakHomeButton();
            maakLogUitButton();
        }

        public void btnVerhuren_Click(object sender, System.EventArgs e)
        {
            //
            // DE ITEMS IN DE DATABASE VERHUURD ZETTEN
            //

            //
            // MET DE DAARBIJ HORENDE RFID
            //

            //
            //
            //
            try
            {
                // Selected  item ..... ..... catch
            }
            catch
            {
                // Als er geen item geselecteerd is.
            }
            MessageBox.Show("Swagerinodino");


        }

        public void btnTerugbrengen_Click(object sender, System.EventArgs e)
        {
            try
            {
                // Selected  item ..... ..... catch
            }
            catch
            {
                // Als er geen item geselecteerd is.
            }
        }

        public void btnLogUit_Click(object sender, System.EventArgs e)
        {
            maakLeeg();
            gbLogin.Visible = true;
        }

        public void btnHome_Click(object sender, System.EventArgs e)
        {
            maakLeeg();
            terugHome();
        }
    }
}
